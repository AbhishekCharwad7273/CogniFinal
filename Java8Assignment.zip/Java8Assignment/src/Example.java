
public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int i,j;
		int no = 1;
		
		for( i=1;i<=3;i++)
		{
			for(j=1;j<=i;j++)
			{
				System.out.print(""+no);
				no++;
			}
			
			System.out.println();
		}
	}

}
