package JavaTrickyQuestion;


@FunctionalInterface
interface car
{
	public void drive();
}


interface Dog extends car
{
	public void bark();
}





public class FunctionalInterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
